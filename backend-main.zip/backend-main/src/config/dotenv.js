module.exports = {
    path : '.env' 
};
