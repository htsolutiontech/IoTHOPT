module.exports = {
    SUCCESS: 'success',
    FAIL: 'fail',
    ERROR: 'error'
};
