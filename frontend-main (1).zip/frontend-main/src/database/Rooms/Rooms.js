export const rooms = [
  {
    id: '62616bb00aa850983c21b11b',
    name: 'Tòa Trung Tâm',
    image: 'ToaTrungTam',
  },
  {
    id: '62616bcfadb8c6e0f01e49dc',
    name: 'Sân Vận Động',
    image: 'Sanbong',
  },
  {
    id: '62618a2af73fe211513926c8',
    name: 'Khu D',
    image: 'KhuD',
  },
  {
    id: '62a9dc30092f09dc52362d94',
    name: 'Khu E',
    image: 'KhuE',
  },
];
