module.exports = [
    {
        "id": "1",
        "username": "Tran Trung",
        "password": "123",
        "email": "trantrung@gmail.com",
        "phone": "09999999999"
    },
    {
        "id": "2",
        "username": "Admin",
        "password": "123",
        "email": "admin@gmail.com",
        "phone": "08888888888"
    }
]