export const Devices = [
  {
    id: '1',
    name: 'Light',
    description: 'Detal light',
    icon: 'light',
  },
  {
    id: '2',
    name: 'Pan',
    description: 'Detal pan',
    icon: 'pan',
  },
  {
    id: '3',
    name: 'Lamp',
    description: 'Detal lamp',
    icon: 'lamp',
  },
  {
    id: '4',
    name: 'Air',
    description: 'Detal Air',
    icon: 'air',
  },
  {
    id: '5',
    name: 'Senser',
    description: 'Detal senser',
    icon: 'chip',
  },
  {
    id: '6',
    name: 'Fire',
    description: 'Detal fire',
    icon: 'fire',
  },
  {
    id: '7',
    name: 'Lock',
    description: 'Detal lock',
    icon: 'lock',
  },
  {
    id: '8',
    name: 'Temperature',
    description: 'Detal temperature',
    icon: 'temperature',
  },
  {
    id: '9',
    name: 'Humidifer',
    description: 'Detal humidifer',
    icon: 'humidifer',
  },
];
